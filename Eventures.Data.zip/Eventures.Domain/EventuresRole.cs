﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Eventures.Domain
{
    public class EventuresRole : IdentityRole
    {
    }
}
